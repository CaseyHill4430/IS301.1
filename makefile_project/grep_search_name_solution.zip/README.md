# Grep Search Name Solution
## Description
This solution uses a bash script to search for lines matching a specified name pattern.
## How to Use
Run the script with the name to search as an argument, providing input via stdin:
./grep_search_name.sh [name] < input_file
## Example
./grep_search_name.sh Lizzy < people_data.txt
## Author
Casey Hill | 11/16/2024
